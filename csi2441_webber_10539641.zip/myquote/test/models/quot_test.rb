require "test_helper"

class QuotTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
